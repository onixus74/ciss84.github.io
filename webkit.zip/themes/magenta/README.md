Magenta Theme for Al Azif's Exploit Host
=======================

Preview:
https://i.imgur.com/nHpw9ZL.png

Author:
@mickyyman